
self.keyboard.press(".")
self.keyboard.press(".")
self.keyboard.press(".")
self.keyboard.slowPress("e")
sleep(0.08)
self.keyboard.keyDown("w")
sleep(0.5)
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
sleep(1.9)
self.keyboard.slowPress(",")
self.keyboard.slowPress(".")
sleep(0.08)
self.keyboard.slowPress(".")
self.keyboard.keyUp("w")
self.keyboard.slowPress("space")
sleep(0.5)




    
