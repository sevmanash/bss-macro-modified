self.keyboard.walk("a",5, False)
self.keyboard.walk("w",2, False)