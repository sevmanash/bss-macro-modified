
self.keyboard.press(".")
self.keyboard.press(".")
self.keyboard.slowPress("e")
sleep(0.45)
self.keyboard.keyDown("w")
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
sleep(1.5)
self.keyboard.keyUp("w")
self.keyboard.press("space")
sleep(1)

    
