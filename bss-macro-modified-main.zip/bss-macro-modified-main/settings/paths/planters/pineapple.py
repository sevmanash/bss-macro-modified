global finalKey
self.keyboard.walk("w",4, False)
self.keyboard.walk("a",4, False)