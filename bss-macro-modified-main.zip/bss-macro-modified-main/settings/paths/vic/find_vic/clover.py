
side = 2
back = 1

self.keyboard.walk("d",0.4)
self.keyboard.walk("w",0.5)
self.keyboard.walk("d",side/2)
self.keyboard.walk("w",back)
self.keyboard.walk("a",side)
self.keyboard.walk("s",back)
self.keyboard.walk("d",side)
self.keyboard.walk("s",back)
self.keyboard.walk("a",side)
self.keyboard.walk("s",back)
self.keyboard.walk("d",side)




    
