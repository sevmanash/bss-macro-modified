self.keyboard.slowPress(".")
self.keyboard.walk("w", 49)
self.keyboard.slowPress(",")
self.runPath(f"field_to_hive/sunflower")