global finalKey
self.keyboard.walk("w",2, False)
self.keyboard.walk("d",4, False)
finalKey = ("a",1)