Some of these patterns I added/modified.
If you want to use them just drag them into patterns, it will not work here

Here are settings I use for each (Can change to what fits you best)
Minutes, Backpack%, and Return To Hive is your choice

All patterns use width as reps
Sorted by name

1. bambe.py - Bamboo
Shift-Lock: On

Size = L
Width = 2-4
Invert = None

Direction = Left
Turn = 4

Location = Upper Left
Distance =  5

2. blue.py - Blue Flower
Shift-Lock: On
Size = M
Width = 3-5
Invert = None

Direction = Left
Turn = 4

Location = Upper Left
Distance = 6

3. colver.py - Clover
Size = M
Width = 1
Invert = None

Direction = None
Turn = 1

Location = Upper Left
Distance = 10

4. dandxsnake.py - Dandelion
Size = M
Width = 5
Invert = None

Direction = Right
Turn = 2

Location = Upper Right
Distance = 9

5. miku_tideshift.py - Pine Tree
Shift-Lock: On
Size = XL
Width = 4-6
Invert = None

Direction = Left
Turn = 4

Location = Upper Left
Distance = 6-7

6. snaildance.py - Stump
May drift out of field, so maybe have less/constant haste or have field drift compensation on
Size = M
Width = 3
Invert = None

Direction = Left
Turn = 2

Location = Lower Right
Distance = 1

7. strawberryxsnake.py
Size = L
Width = 6 (Less if you collect more red pollen)
Invert = None

Direction = None
Turn = 1

Location = Right
Distance = 8-9

8. sun.py
Size = L
Width = 3 
Invert = Left/Right

Direction = None
Turn = 1

Location = Left
Distance = 3


Can use patterns for other fields, choose based on preference 