global finalKey
self.keyboard.walk("w",0.4)
self.keyboard.walk("d",2, False)
self.keyboard.walk("s",2, False)
finalKey = ("a",0.23)