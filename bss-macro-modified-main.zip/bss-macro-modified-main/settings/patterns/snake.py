

for i in range(2):
    self.keyboard.walk(tcfbkey, 0.72*size)
    self.keyboard.walk(tclrkey, 0.1*width)
    self.keyboard.walk(afcfbkey, 0.72*size)
    self.keyboard.walk(tclrkey, 0.1*width)
for i in range(2):
    self.keyboard.walk(tcfbkey, 0.72*size)
    self.keyboard.walk(afclrkey, 0.1*width)
    self.keyboard.walk(afcfbkey, 0.72*size)
    self.keyboard.walk(afclrkey, 0.1*width)
        
    
    
