

side = 2
back = 0.8
self.keyboard.walk("w",back)
self.keyboard.walk("a",side)
time.sleep(0.7)
self.keyboard.walk("s",back)
self.keyboard.walk("d",side)
time.sleep(0.7)

    
