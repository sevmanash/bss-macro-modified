for _ in range(3):
    self.keyboard.slowPress(".")
self.keyboard.walk("w",11)
for _ in range(3):
    self.keyboard.slowPress(",")
self.runPath(f"field_to_hive/pine tree")
    
