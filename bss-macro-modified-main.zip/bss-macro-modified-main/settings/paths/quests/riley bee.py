self.keyboard.slowPress(".")
self.keyboard.slowPress("e")
time.sleep(0.12)
self.keyboard.keyDown("w")
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
time.sleep(2.2)
self.keyboard.slowPress(".")
time.sleep(0.5)
self.keyboard.keyUp("w")
time.sleep(0.6)
self.keyboard.slowPress("space")
time.sleep(0.5)
self.keyboard.walk("w",1.8)
self.keyboard.keyDown("w")
sleep(0.1)
self.keyboard.slowPress("space")
sleep(0.3)
self.keyboard.keyUp("w")




    
