global finalKey
self.keyboard.walk("a",3, False)
self.keyboard.walk("w",4, False)
finalKey = ("s",0.25)