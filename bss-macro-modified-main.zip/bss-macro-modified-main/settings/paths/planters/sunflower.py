global finalKey
self.keyboard.walk("a",3, False)
self.keyboard.walk("s",4.5, False)
self.keyboard.walk("d",0.2)
finalKey = ("w",0.5)