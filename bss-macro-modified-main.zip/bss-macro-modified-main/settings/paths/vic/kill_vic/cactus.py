
side = 2.5
back = 1.2

self.keyboard.walk("s",back)
self.keyboard.walk("a",side)
time.sleep(0.7)
self.keyboard.walk("w",back)
self.keyboard.walk("d",side)
time.sleep(0.7)


    
