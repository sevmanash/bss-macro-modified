exec(open("../settings/paths/collect/stockings.py").read())
self.keyboard.walk("a",1.25, False)
self.keyboard.walk("s",1.5)
self.keyboard.walk("d",0.45)
