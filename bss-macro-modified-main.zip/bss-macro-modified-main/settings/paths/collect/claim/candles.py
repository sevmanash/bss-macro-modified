time.sleep(2)
self.keyboard.walk('d',0.2)
self.keyboard.walk('w',1,False)
self.keyboard.walk('a',0.5)
self.keyboard.walk('d',1)
   

    
