
side = 2
back = 1.2

self.keyboard.walk("a",side)
self.keyboard.walk("w",back)
time.sleep(0.7)
self.keyboard.walk("d",side)
self.keyboard.walk("s",back)
time.sleep(0.7)

    
