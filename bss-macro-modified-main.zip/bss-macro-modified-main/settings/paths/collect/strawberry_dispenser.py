
self.keyboard.slowPress(".")
self.keyboard.slowPress("e")
time.sleep(0.12)
self.keyboard.keyDown("w")
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
time.sleep(3.55)
self.keyboard.slowPress(".")
time.sleep(0.1)
self.keyboard.keyUp("w")
self.keyboard.slowPress("space")
time.sleep(0.5)
self.keyboard.walk("s",0.05)
self.keyboard.walk("d",1)




    
