
self.keyboard.walk(tcfbkey,0.5*size)
for _ in range(width):
    self.keyboard.walk(tclrkey,0.125*(width/4))
    self.keyboard.walk(tclrkey,0.125*(width/4))
for _ in range(width):
    self.keyboard.walk(afcfbkey,0.5*size)
    self.keyboard.walk(afclrkey,0.125*(width/4))
    self.keyboard.walk(tcfbkey,0.5*size)
    self.keyboard.walk(afclrkey,0.125*(width/4))
self.keyboard.walk(afcfbkey,0.5*size)
for _ in range(width):
    self.keyboard.walk(tclrkey,0.125*(width/4))
    self.keyboard.walk(tclrkey,0.125*(width/4))
for _ in range(width):
    self.keyboard.walk(tcfbkey,0.5*size)
    self.keyboard.walk(afclrkey,0.125*(width/4))
    self.keyboard.walk(afcfbkey,0.5*size)
    self.keyboard.walk(afclrkey,0.125*(width/4))
