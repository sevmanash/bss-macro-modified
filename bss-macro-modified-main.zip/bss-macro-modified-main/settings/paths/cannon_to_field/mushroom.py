
self.keyboard.slowPress(",")
self.keyboard.slowPress(",")
self.keyboard.slowPress(",")
self.keyboard.slowPress("e")
self.keyboard.keyDown("w")
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
self.keyboard.keyUp("w")
self.keyboard.slowPress("space")
self.keyboard.slowPress(",")
#self.keyboard.walk("s",0.4)
sleep(1)

    
