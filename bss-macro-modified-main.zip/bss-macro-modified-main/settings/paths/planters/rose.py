global finalKey
self.keyboard.multiWalk(["a", "s"], 6)
finalKey = ("w", 0.7)