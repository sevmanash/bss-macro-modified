self.keyboard.walk("w",3, False)
self.keyboard.walk("a",4, False)