self.keyboard.press(".")
self.keyboard.press(".")
self.keyboard.press(".")
self.keyboard.slowPress("e")
sleep(0.08)
self.keyboard.keyDown("w")
sleep(0.5)
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
sleep(1.4)
self.keyboard.slowPress(",")
sleep(0.35)
self.keyboard.slowPress("space")
self.keyboard.keyUp("w")
self.keyboard.press(",")
self.keyboard.press(",")
sleep(0.8)




    
