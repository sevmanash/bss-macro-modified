self.keyboard.walk("d",3, False)
self.keyboard.walk("s",5, False)
self.keyboard.keyDown("a")
time.sleep(7.5)
self.keyboard.press("space")
time.sleep(4.5)
self.keyboard.keyUp("a")
self.runPath(f"field_to_hive/coconut")







    
