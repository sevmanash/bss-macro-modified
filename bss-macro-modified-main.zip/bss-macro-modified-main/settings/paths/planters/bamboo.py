global finalKey
self.keyboard.walk("w",3, False)
self.keyboard.walk("d",4, False)
finalKey = ("a",0.25)