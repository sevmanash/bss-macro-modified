
self.keyboard.slowPress(",")
self.keyboard.slowPress(",")
self.keyboard.slowPress(",")
self.keyboard.slowPress("e")
sleep(0.3)
self.keyboard.keyDown("w")
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
self.keyboard.slowPress(",")
self.keyboard.keyUp("w")
self.keyboard.slowPress("space")
sleep(1.2)

    
