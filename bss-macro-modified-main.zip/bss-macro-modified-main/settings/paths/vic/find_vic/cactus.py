
side = 3
back = 1.4
self.keyboard.walk("d",1.33)
self.keyboard.walk("w",0.4)
time.sleep(1)
self.keyboard.walk("d",side/2)
self.keyboard.walk("w",back/2)
self.keyboard.walk("a",side)
self.keyboard.walk("s",back)
self.keyboard.walk("d",side)



    
