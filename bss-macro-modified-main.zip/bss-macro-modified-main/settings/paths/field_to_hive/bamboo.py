
self.keyboard.walk("w",0.5)
self.keyboard.walk("a",7)
self.keyboard.walk("w",7, False)
self.runPath(f"field_to_hive/blue flower")

    
