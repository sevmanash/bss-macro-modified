
self.keyboard.slowPress("e")
sleep(2)
    
