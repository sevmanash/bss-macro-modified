$("#changelog-placeholder")
.load("../htmlImports/tabs/changelog.html") //load changelog tab