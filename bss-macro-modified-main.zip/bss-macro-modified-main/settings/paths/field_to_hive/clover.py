self.keyboard.walk("s",8, False)
self.runPath(f"field_to_hive/blue flower")
