
self.keyboard.press(",")
self.keyboard.press(",")
self.keyboard.slowPress("e")
sleep(0.08)
self.keyboard.keyDown("w")
self.keyboard.slowPress("space")
self.keyboard.slowPress("space")
sleep(3)
self.keyboard.slowPress(".")
self.keyboard.slowPress(".")
sleep(0.8)
self.keyboard.keyUp("w")
self.keyboard.slowPress("space")
sleep(0.6)

    
