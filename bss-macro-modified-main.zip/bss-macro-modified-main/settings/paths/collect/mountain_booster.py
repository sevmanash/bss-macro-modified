global fields
fields = ["sunflower", "dandelion", "spider", "clover", "pineapple", "pumpkin", "cactus"]
self.keyboard.slowPress('e')
sleep(3)
self.keyboard.walk("d",6)

