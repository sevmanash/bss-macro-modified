for i in range(width):
    self.keyboard.walk(tcfbkey,0.4*(size+i/1.5))
    self.keyboard.walk(afclrkey,0.4*(size+i/1.5))
    self.keyboard.walk(afcfbkey,0.4*(size+i/1.5))
    self.keyboard.walk(tclrkey,0.4*(size+i/1.5))
    
 

    
    
