global fields
fields = ["rose", "strawberry", "mushroom"]
self.goToField("rose", "south")
self.keyboard.press("space")
self.keyboard.walk("s",1)
self.keyboard.walk("a",4)
self.keyboard.walk("s",3)
self.keyboard.walk("w",5)
self.keyboard.walk("d",1.9)
self.keyboard.walk("w",4)
